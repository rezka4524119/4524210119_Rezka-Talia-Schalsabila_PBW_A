<?php

use Illuminate\Database\Migrations\Migration;

use Illuminate\Database\Schema\Blueprint;

use Illuminate\Support\Facades\Schema;

return new class extends Migration

{

    public function up(): void

    {

        Schema::create('pesan_tamus', function (Blueprint $table) {

            $table->id();

            $table->string('nama');

            $table->string('email');

            $table->text('pesan');

            $table->timestamps();

        });

    }

    public function down(): void

    {

        Schema::dropIfExists('pesan_tamus');

    }

};
