# Praktikum Pemrograman Berbasis Web (PBW)

Repository ini berisi kumpulan tugas praktikum mata kuliah Pemrograman Berbasis Web.

## Identitas Mahasiswa

- **Nama:** Rezka Talia Schalsabila
- **NPM:** 4524210119
- **Mata Kuliah:** Pemrograman Berbasis Web

## Daftar Praktikum

### Praktikum 1 dan 2 — PHP Dasar dan HTTP Method
Berisi latihan dan implementasi materi dasar PHP serta penggunaan HTTP Method.

### Praktikum 3 — Laravel dan Blade View
Berisi pengembangan project LaraPress menggunakan Laravel, termasuk pengaturan route dan pembuatan halaman web.

### Praktikum 4 — Authentication
Berisi implementasi autentikasi pengguna, meliputi registrasi, login, logout, session, dan perlindungan halaman.

### Praktikum 5 — Website SMP Mentari Ceria
Berisi pengembangan website SMP Mentari Ceria dengan fitur buku tamu, autentikasi, dashboard, pengelolaan kegiatan, dan pengaturan website.

## Teknologi

Teknologi yang digunakan menyesuaikan dengan masing-masing praktikum, antara lain PHP dan Laravel.

## Tujuan

Repository ini digunakan untuk mendokumentasikan proses pengerjaan dan hasil praktikum Pemrograman Berbasis Web.

## Catatan

Source code, dokumentasi, dan screenshot hasil praktikum dapat dilihat pada folder masing-masing praktikum.
